package com.devMenthors.moneySearch.money_search

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
