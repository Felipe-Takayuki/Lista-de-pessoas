/// string global para representar chave do cache
const String pessoas = "pessoas";
